#!/bin/bash
# Script to make the deployment script executable

chmod +x deploy.sh
echo "Made deploy.sh executable. You can now run it with ./deploy.sh"
